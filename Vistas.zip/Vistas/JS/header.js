
function toggleMenu() {
    var menu = document.getElementById('menu');
    menu.classList.toggle('open');
}